const express = require('express');
const bodyParser = require('body-parser');
const mongo = require('mongodb');

(async () => {
  
  const app = express();
  app.use(bodyParser.json());

  const client = await mongo.MongoClient.connect('mongodb://localhost:27017', { useUnifiedTopology: true });
  const db = client.db('examples');
  
  const collection = db.collection("files");  

  const route = '/api/files'

  app.get(route, async (req, res) => {
    const files = await collection.find().toArray();
    res.send(files);
  });

  app.post(route, async (req, res) => {
    const file = req.body;
    await collection.insertOne(file); 
    res.status(201); 
    res.send(file);
  });

  app.delete(`${route}/:id`, async (req, res)=> {
    const id = mongo.ObjectID(req.params.id);
    const deleteC = (await collection.deleteOne({_id: id})).deletedCount;
    if(deleteC === 0){
      res.status(404);
      res.send({error: "Not found!"})
      return;
    }
    res.send();
  }); 

  app.listen(3000, () => console.log('Listening on port 3000'));
})();

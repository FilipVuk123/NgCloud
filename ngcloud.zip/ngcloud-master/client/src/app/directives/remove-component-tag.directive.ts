import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[appRemoveComponentTag]'
})
export class RemoveComponentTagDirective {

  constructor(public elem: ElementRef) { }
  
  ngOnInit() {
    var native: HTMLElement = this.elem.nativeElement;
    let parent: any = native.parentElement;
    
    while (native.firstChild) {
        parent.insertBefore(native.firstChild, native);
    }
    
    parent.removeChild(native);
  }
}

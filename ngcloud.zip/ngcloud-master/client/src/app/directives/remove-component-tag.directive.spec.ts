import { RemoveComponentTagDirective } from './remove-component-tag.directive';

describe('RemoveComponentDirective', () => {
  it('should create an instance', () => {
    const directive = new RemoveComponentTagDirective();
    expect(directive).toBeTruthy();
  });
});

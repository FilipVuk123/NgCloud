import { ExtensionPipe } from './extension.pipe';

describe('ExtensionPipe', () => {
  it('create an instance', () => {
    const pipe = new ExtensionPipe();
    expect(pipe).toBeTruthy();
  });
});

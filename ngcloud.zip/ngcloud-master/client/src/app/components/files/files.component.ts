import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from "@angular/router"
import { BehaviorSubject, Subscription } from 'rxjs';
import { FileMetadata } from "../../classes/classes"
import { FilesService } from "../../files.service"


@Component({
  selector: 'app-files',
  templateUrl: './files.component.html',
  styleUrls: ['./files.component.scss']
})
export class FilesComponent implements OnInit, OnDestroy{

  private filesSubscription: Subscription = new Subscription;

  filesSubject: BehaviorSubject<FileMetadata[]> = new BehaviorSubject<FileMetadata[]>([]);

  constructor(private router: Router, private readonly filesService: FilesService) { }

  ngOnInit(): void {
    this.filesSubject = this.filesService.files;
  }
  
  btnClicked(): void {
    this.router.navigate(['/files/newFile'])
  }
  ngOnDestroy(): void {
    this.filesSubscription.unsubscribe()
  }
};

import { Component, OnInit } from '@angular/core';
import { FileMetadata } from "../../classes/classes"
import { Input, Output, EventEmitter } from "@angular/core"
import { FilesService } from "../../files.service"
import { Router } from '@angular/router';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss']
})
export class TableComponent implements OnInit {
  @Input() 
  row: FileMetadata = new FileMetadata("","",0);

  @Output() 
  deleteClick: EventEmitter<FileMetadata> = new EventEmitter<FileMetadata>();


  constructor(private filesService: FilesService, private router: Router) { 
    
  };
  
  toDelete(){
    this.filesService.removeFile(this.row).subscribe();
  }

  ngOnInit(): void {
    
  }; 
}


import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from "@angular/router"
import { FilesService } from 'src/app/files.service';
import { FileMetadata } from 'src/app/classes/classes';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-new-file',
  templateUrl: './new-file.component.html',
  styleUrls: ['./new-file.component.scss']
})
export class NewFileComponent implements OnInit, OnDestroy{

  newFileForm: FormGroup = new FormGroup({
    name: new FormControl("", Validators.required)
  });

  private filesSubscription: Subscription = new Subscription;

  constructor(private router: Router, private filesService: FilesService) { }

  ngOnInit(): void {}
  
  btnClicked(){
    this.router.navigate(['/files'])
  }

  onSubmit(){
    const name = String(this.newFileForm.controls['name'].value);
    const now = new Date()//.toLocaleString();
    const dd = now.getDay();
    const mm = now.getMonth() + 1;
    const yy = now.getFullYear() - 2000;
    const time = now.toLocaleTimeString()
    const added = `${dd}/${mm}/${yy} ${time}`
    const size = Math.floor(Math.random() * 10) + 1 
    const newFile: FileMetadata = {name: name, size : size, added : added}
    this.filesSubscription = this.filesService.postFile(newFile).subscribe(() => this.router.navigate(['/files']))
  }
  ngOnDestroy(){
    this.filesSubscription.unsubscribe();
  } 
}

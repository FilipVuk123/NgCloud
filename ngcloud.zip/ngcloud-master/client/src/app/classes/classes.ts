export class FileMetadata{
    public name: string;
    public added: string;
    public size: number;
    public _id?: string;
    constructor(n:string, a:string, s:number, id?:string){
        this.name = n;
        this.size = s;
        this.added = a;
        this._id = id;
    }
}
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'extension'
})
export class ExtensionPipe implements PipeTransform {

  transform(value: string): string {
    const ext = value.substr(value.length - 4);
    const path = "../../../assets/img/";
    if (ext === ".jpg"){
      return path + 'jpg.png'; 
    }
    else if (ext === ".mp3"){
      return path + 'mp3.png';
    }
    else if (ext === ".doc" || ext === "docx"){
      return path + 'doc.png';
    }
    else if (ext === ".pdf"){
      return path + 'pdf.png';
    }
    else if (ext === ".ppt" || ext === "pptx"){
      return path + 'ppt.png';
    }
    else if (ext === ".txt"){
      return path + 'txt.png';
    }
    else if (ext === ".xls" ||ext === "xlsx"){
      return path + 'xls.png';
    }
    else{ 
      return path + 'file.png';
    }
  }
}

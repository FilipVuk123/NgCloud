import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { FileMetadata } from './classes/classes'

@Injectable({
  providedIn: 'root',
})
export class FilesService {

  private readonly url = '/api/files';

  public files: BehaviorSubject<FileMetadata[]> = new BehaviorSubject<FileMetadata[]>([]);

  constructor(private readonly http: HttpClient) {
    this.getFiles().subscribe();
  }
   
  getFiles(): Observable<FileMetadata[]>{
    return this.http.get<FileMetadata[]>(this.url)
      .pipe(
        tap((files: FileMetadata[]) => this.files.next(files))
      )
  }

  postFile(file: FileMetadata): Observable<FileMetadata>{
    return this.http.post<FileMetadata>(this.url, file) 
    .pipe(
      tap((file: FileMetadata) => this.files.next([...this.files.getValue(), file]))
    );
  }
  
  removeFile(file: FileMetadata): Observable<FileMetadata>{
    const fid = file._id
    return this.http.delete<FileMetadata>(`${this.url}/${fid}`).pipe(
      tap(() => this.files.next(this.files.getValue().filter((file: FileMetadata) => {return fid !== file._id})))
    )
  }
}

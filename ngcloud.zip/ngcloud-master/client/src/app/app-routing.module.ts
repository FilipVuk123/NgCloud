import { NgModule } from '@angular/core';
import { Routes, RouterModule, Router } from '@angular/router';
import { FilesComponent } from './components/files/files.component';
import { NewFileComponent } from './components/new-file/new-file.component';
import { ProfileComponent } from './components/profile/profile.component';

const routes: Routes = [
  { path: "", pathMatch: "full", redirectTo: "files"},
  { path: "files", component: FilesComponent },
  { path: "profile", component: ProfileComponent },
  { path: "files/newFile", component: NewFileComponent },
  { path: "**", redirectTo: "files"}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }